//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
// $Id: B1DetectorConstruction.cc 94307 2015-11-11 13:42:46Z gcosmo $
//
/// \file B1DetectorConstruction.cc
/// \brief Implementation of the B1DetectorConstruction class

#include "B1DetectorConstruction.hh"

#include "G4RunManager.hh"
#include "G4NistManager.hh"
#include "G4Box.hh"
#include "G4Cons.hh"
#include "G4Orb.hh"
#include "G4Sphere.hh"
#include "G4Trd.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4SystemOfUnits.hh"
#include "G4Tubs.hh"

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

B1DetectorConstruction::B1DetectorConstruction()
: G4VUserDetectorConstruction(),
  fScoringVolume(0)
{ 


}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

B1DetectorConstruction::~B1DetectorConstruction()
{ }

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

G4VPhysicalVolume* B1DetectorConstruction::Construct()
{  
  // Get nist material manager
  G4NistManager* nist = G4NistManager::Instance();
  
  // Option to switch on/off checking of volumes overlaps
  //
  G4bool checkOverlaps = true;

  //     
  // World
  //
  G4double world_sizeXY = 100*cm;
  G4double world_sizeZ  = 100*cm;
  G4Material* world_mat = nist->FindOrBuildMaterial("G4_AIR");
  
  G4Box* solidWorld =    
    new G4Box("World",                       //its name
       0.5*world_sizeXY, 0.5*world_sizeXY, 0.5*world_sizeZ);     //its size
      
  G4LogicalVolume* logicWorld =                         
    new G4LogicalVolume(solidWorld,          //its solid
                        world_mat,           //its material
                        "World");            //its name
                                   
  G4VPhysicalVolume* physWorld = 
    new G4PVPlacement(0,                     //no rotation
                      G4ThreeVector(),       //at (0,0,0)
                      logicWorld,            //its logical volume
                      "World",               //its name
                      0,                     //its mother  volume
                      false,                 //no boolean operation
                      0,                     //copy number
                      checkOverlaps);        //overlaps checking
  

	// create 2 in NaI crystal
	// note these dimensions are probably wrong!!
	G4double NaI_r = 7.41*cm; // Dylan - Editing the radius to build realistic casing
	G4double NaI_hz = 5.08*cm;
	G4Tubs* NaI_2inch_shape = new G4Tubs("NaI_2inch", 0*mm, NaI_r, NaI_hz, 0*deg, 360*deg);	
	G4LogicalVolume* NaI_2inch_log = new G4LogicalVolume(NaI_2inch_shape, nist->FindOrBuildMaterial("G4_SODIUM_IODIDE"), "NaI_2inch");

// Creating Aluminium Oxide layer
  G4double Al2O3_2r = 7.57*cm;
  G4double Al2O3_2hz = 5.24*cm;
  G4Tubs* Al2O3_2inch_shape = new G4Tubs("Al2O3_2inch", NaI_r, Al2O3_2r, Al2O3_2hz, 0*deg, 360*deg);
  G4LogicalVolume* Al2O3_2inch_log = new G4LogicalVolume(Al2O3_2inch_shape, nist->FindOrBuildMaterial("G4_ALUMINUM_OXIDE"), "Al2O3_2inch");

  // Creating Aluminium layer
  G4double Al_2r = 7.62*cm;
  G4double Al_2hz = 5.29*cm;
  G4Tubs* Al_2inch_shape = new G4Tubs("Al_2inch", Al2O3_2r, Al_2r, Al_2hz, 0*deg, 360*deg);
  G4LogicalVolume* Al_2inch_log = new G4LogicalVolume(Al_2inch_shape, nist->FindOrBuildMaterial("G4_Al"), "Al_2inch");

	// create 1 in NaI crystal
	// note these dimensions are probably wrong!!
	G4double NaI_1inch_r = 7.41*cm;
	G4double NaI_1inch_hz = 5.08*cm;
	G4Tubs* NaI_1inch_shape = new G4Tubs("NaI_1inch", 0*mm, NaI_1inch_r, NaI_1inch_hz, 0*deg, 360*deg);	
	G4LogicalVolume* NaI_1inch_log = new G4LogicalVolume(NaI_1inch_shape, nist->FindOrBuildMaterial("G4_SODIUM_IODIDE"), "NaI_1inch");

  // Creating Aluminium Oxide layer
  G4double Al2O3_1r = 7.57*cm;
  G4double Al2O3_1hz = 5.24*cm;
  G4Tubs* Al2O3_1inch_shape = new G4Tubs("Al2O3_1inch", NaI_1inch_r, Al2O3_1r, Al2O3_1hz, 0*deg, 360*deg);
  G4LogicalVolume* Al2O3_1inch_log = new G4LogicalVolume(Al2O3_1inch_shape, nist->FindOrBuildMaterial("G4_ALUMINUM_OXIDE"), "Al2O3_1inch");

// Creating Aluminium layer
  G4double Al_1r = 7.62*cm;
  G4double Al_1hz = 5.29*cm;
  G4Tubs* Al_1inch_shape = new G4Tubs("Al_1inch", Al2O3_1r, Al_1r, Al_1hz, 0*deg, 360*deg);
  G4LogicalVolume* Al_1inch_log = new G4LogicalVolume(Al_1inch_shape, nist->FindOrBuildMaterial("G4_Al"), "Al_1inch");

// Creating lead blocks
  /*G4double Pb_x = 0;
  G4double Pb_y = 0;
  G4double Pb_z = 10*cm;
  G4double Pb_hx = 5*cm;
  G4double Pb_hy = 10*cm; // These are the half measurements of the lead blocks we use
  G4double Pb_hz = 2.5*cm;
  G4Box* Pb_shape = new G4Box("Lead_Block", Pb_hx, Pb_hy, Pb_hz);
  G4LogicalVolume* Lead_Block = new G4LogicalVolume(Pb_shape, nist->FindOrBuildMaterial("G4_Pb"), "Lead_Block");
  G4ThreeVector Lead_pos = G4ThreeVector(Pb_x, Pb_y, Pb_z);
    new G4PVPlacement(0, Lead_pos, "Lead", Lead_Block, physWorld, false, 0, checkOverlaps); */

	G4RotationMatrix* absorber1_rot = new G4RotationMatrix();
	absorber1_rot->rotateX(90*deg);
	G4ThreeVector absorber1_pos = G4ThreeVector(0*cm,2*Al_2r,40*cm);
		new G4PVPlacement(absorber1_rot, absorber1_pos, "absorber", NaI_2inch_log, physWorld, false, 0, checkOverlaps);
// Rotating Aluminium Oxide Layer
		new G4PVPlacement(absorber1_rot, absorber1_pos, "absorber_Al2O3", Al2O3_2inch_log, physWorld, false, 0, checkOverlaps);
// Rotating Aluminium Layer
    new G4PVPlacement(absorber1_rot, absorber1_pos, "absorber_Al", Al_2inch_log, physWorld, false, 0, checkOverlaps);


	G4RotationMatrix* absorber2_rot = new G4RotationMatrix();
	absorber2_rot->rotateX(90*deg);
	G4ThreeVector absorber2_pos = G4ThreeVector(0*cm,-2*Al_2r,40*cm);
		new G4PVPlacement(absorber2_rot, absorber2_pos, "absorber", NaI_2inch_log, physWorld, false, 1, checkOverlaps);
// Rotating Aluminium Oxide Layer
		new G4PVPlacement(absorber2_rot, absorber2_pos, "absorber_Al2O3", Al2O3_2inch_log, physWorld, false, 1, checkOverlaps);
// Rotating Aluminium Layer
    new G4PVPlacement(absorber2_rot, absorber2_pos, "absorber_Al", Al_2inch_log, physWorld, false, 1, checkOverlaps);

  G4RotationMatrix* absorber3_rot = new G4RotationMatrix();
	absorber3_rot->rotateX(90*deg);
	G4ThreeVector absorber3_pos = G4ThreeVector(-2*Al_2r,0,40*cm);
		new G4PVPlacement(absorber3_rot, absorber3_pos, "absorber", NaI_2inch_log, physWorld, false, 2, checkOverlaps);
// Rotating Aluminium Oxide Layer
		new G4PVPlacement(absorber3_rot, absorber3_pos, "absorber_Al2O3", Al2O3_2inch_log, physWorld, false, 2, checkOverlaps);
// Rotating Aluminium Layer
    new G4PVPlacement(absorber3_rot, absorber3_pos, "absorber_Al", Al_2inch_log, physWorld, false, 2, checkOverlaps);

  G4RotationMatrix* absorber4_rot = new G4RotationMatrix();
	absorber3_rot->rotateX(90*deg);
	G4ThreeVector absorber4_pos = G4ThreeVector(2*Al_2r,0,40*cm);
		new G4PVPlacement(absorber4_rot, absorber4_pos, "absorber", NaI_2inch_log, physWorld, false, 3, checkOverlaps);
// Rotating Aluminium Oxide Layer
		new G4PVPlacement(absorber4_rot, absorber4_pos, "absorber_Al2O3", Al2O3_2inch_log, physWorld, false, 3, checkOverlaps);
// Rotating Aluminium Layer
    new G4PVPlacement(absorber4_rot, absorber4_pos, "absorber_Al", Al_2inch_log, physWorld, false, 3, checkOverlaps);

	G4RotationMatrix* scatterer1_rot = new G4RotationMatrix();
	scatterer1_rot->rotateX(0*deg);
	G4ThreeVector scatterer1_pos = G4ThreeVector(-4*Al_2r,2*Al_2r,20*cm);
		new G4PVPlacement(scatterer1_rot, scatterer1_pos, "scatterer", NaI_1inch_log, physWorld, false, 0, checkOverlaps);	
// Rotating Aluminium Oxide Layer
		new G4PVPlacement(scatterer1_rot, scatterer1_pos, "scatterer_Al2O3", Al2O3_1inch_log, physWorld, false, 0, checkOverlaps);
// Rotating Aluminium Layer
    new G4PVPlacement(scatterer1_rot, scatterer1_pos, "scatterer_Al", Al_1inch_log, physWorld, false, 0, checkOverlaps);
	
  G4RotationMatrix* scatterer2_rot = new G4RotationMatrix();
	scatterer2_rot->rotateX(0*deg);
	G4ThreeVector scatterer2_pos = G4ThreeVector(4*Al_2r,2*Al_2r,20*cm);
		new G4PVPlacement(scatterer2_rot, scatterer2_pos, "scatterer", NaI_1inch_log, physWorld, false, 1, checkOverlaps);	
// Rotating Aluminium Oxide Layer
		new G4PVPlacement(scatterer2_rot, scatterer2_pos, "scatterer_Al2O3", Al2O3_1inch_log, physWorld, false, 1, checkOverlaps);
// Rotating Aluminium Layer
    new G4PVPlacement(scatterer2_rot, scatterer2_pos, "scatterer_Al", Al_1inch_log, physWorld, false, 1, checkOverlaps);

  G4RotationMatrix* scatterer3_rot = new G4RotationMatrix();
	scatterer2_rot->rotateX(0*deg);
	G4ThreeVector scatterer3_pos = G4ThreeVector(4*Al_2r,-2*Al_2r,20*cm);
		new G4PVPlacement(scatterer3_rot, scatterer3_pos, "scatterer", NaI_1inch_log, physWorld, false, 2, checkOverlaps);	
// Rotating Aluminium Oxide Layer
		new G4PVPlacement(scatterer3_rot, scatterer3_pos, "scatterer_Al2O3", Al2O3_1inch_log, physWorld, false, 2, checkOverlaps);
// Rotating Aluminium Layer
    new G4PVPlacement(scatterer3_rot, scatterer3_pos, "scatterer_Al", Al_1inch_log, physWorld, false, 2, checkOverlaps);

  G4RotationMatrix* scatterer4_rot = new G4RotationMatrix();
	scatterer2_rot->rotateX(0*deg);
	G4ThreeVector scatterer4_pos = G4ThreeVector(-4*Al_2r,-2*Al_2r,20*cm);
		new G4PVPlacement(scatterer4_rot, scatterer4_pos, "scatterer", NaI_1inch_log, physWorld, false, 3, checkOverlaps);	
// Rotating Aluminium Oxide Layer
		new G4PVPlacement(scatterer4_rot, scatterer4_pos, "scatterer_Al2O3", Al2O3_1inch_log, physWorld, false, 3, checkOverlaps);
// Rotating Aluminium Layer
    new G4PVPlacement(scatterer4_rot, scatterer4_pos, "scatterer_Al", Al_1inch_log, physWorld, false, 3, checkOverlaps);

 //
  //always return the physical World
  //
  return physWorld;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
